<footer>
	<div class="container">
		<div class="headd">
			<img src="images/logo-white.png">
			<img src="images/footer-imgg.png">
		</div>
		<div class="bodyy">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="about.php">About Us</a></li>
				<li><a href="pricing.php">Packages</a></li>
				<li><a href="sample-report.php">Sample Report</a></li>
				<li><a href="vehicle-history.php">Vehicle History Report</a></li>
			</ul>
		</div>
		<div class="footerr">
			<p>© Since 1999 - 2024 CVF Designs and Solutions LLC, All rights reserved</p>
			<img src="images/visa.png">
		</div>
	</div>
</footer>
